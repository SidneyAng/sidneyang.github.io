// Você pode usar isso depois pra colocar alertas, formulários, etc.
console.log("Sol na Rede carregado!");